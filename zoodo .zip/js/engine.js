// ================================
// ZOODO IA - ENGINE (FUSION FINALE)
// ================================

async function generateReply(incomingText, meta = {}) {
  const message = incomingText.toLowerCase().trim();

  // ---------- CONTACTS / EXCLUSIONS ----------
  const excluded = (localStorage.getItem("contacts_excluded_list") || "")
    .toLowerCase()
    .split("\n")
    .filter(Boolean);

  if (meta.sender && excluded.includes(meta.sender.toLowerCase())) {
    return null; // ne pas répondre
  }

  // ---------- MESSAGE DE BIENVENUE ----------
  const welcomeEnabled = localStorage.getItem("welcome_enabled") === "true";
  const welcomeText = localStorage.getItem("welcome_text");

  if (welcomeEnabled && meta.firstMessage && welcomeText) {
    return welcomeText;
  }

  // ---------- MOTS-CLÉS ----------
  const keywords = JSON.parse(localStorage.getItem("keywords")) || [];
  for (let k of keywords) {
    if (message.includes(k.word.toLowerCase())) {
      return k.reply;
    }
  }

  // ---------- IA ----------
  const iaKey = localStorage.getItem("ia_key");
  const iaProvider = localStorage.getItem("ia_provider");

  if (iaKey && iaProvider) {
    try {
      const iaResponse = await callIA(iaProvider, iaKey, incomingText);
      if (iaResponse) return iaResponse;
    } catch (e) {
      console.error("IA error:", e);
    }
  }

  // ---------- RÉPONSE AUTOMATIQUE ----------
  const autoReply = localStorage.getItem("auto_reply_text");
  if (autoReply) return autoReply;

  // ---------- AUCUNE RÈGLE ----------
  return "Aucune règle ne correspond.";
}

// ================================
// APPEL IA (OpenAI / Gemini)
// ================================
async function callIA(provider, apiKey, userMessage) {
  if (provider === "openai") {
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + apiKey
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content:
              "Tu es un assistant de réponse automatique. Réponds brièvement, naturellement, sans dire que tu es une IA."
          },
          { role: "user", content: userMessage }
        ],
        max_tokens: 120
      })
    });

    const data = await res.json();
    return data.choices?.[0]?.message?.content || null;
  }

  if (provider === "gemini") {
    const res = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=" +
        apiKey,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: userMessage }] }]
        })
      }
    );

    const data = await res.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text || null;
  }

  return null;
}