document.addEventListener("DOMContentLoaded", function () {

  // ====== NAVIGATION DES CARTES (MENU PRINCIPAL) ======

  const cards = document.querySelectorAll(".card");

  cards.forEach(card => {
    card.addEventListener("click", () => {
      const title = card.querySelector("h4").innerText.trim();

      switch (title) {

        case "Réponse IA":
          window.location.href = "ia.html";
          break;

        case "Réponse par mot-clé":
          window.location.href = "keywords.html";
          break;

        case "Réponse automatique":
          window.location.href = "auto-reply.html";
          break;

        case "Message de bienvenue":
          window.location.href = "welcome.html";
          break;

        case "Applications prises en charge":
          window.location.href = "apps.html";
          break;

        case "Contacts":
          window.location.href = "contacts.html";
          break;

        case "Statistiques":
          window.location.href = "stats.html";
          break;

        case "Test Reply":
          window.location.href = "test.html";
          break;

        default:
          alert("Fonction en cours de développement : " + title);
      }
    });
  });

  // ====== ÉTAT DU SERVICE (ON / OFF) ======

  const serviceToggle = document.getElementById("serviceToggle");
  const statusText = document.getElementById("statusText");

  if (serviceToggle && statusText) {
    const savedState = localStorage.getItem("service_enabled") === "true";
    serviceToggle.checked = savedState;
    updateServiceStatus(savedState);

    serviceToggle.addEventListener("change", () => {
      const isEnabled = serviceToggle.checked;
      localStorage.setItem("service_enabled", isEnabled);
      updateServiceStatus(isEnabled);
    });
  }

  function updateServiceStatus(enabled) {
    statusText.textContent = enabled ? "Service activé" : "Service désactivé";
    statusText.style.color = enabled ? "green" : "red";
  }

});
// ================================
// GESTION PUB DISCRÈTE (SMART)
// ================================

function canShowAd() {
  const last = localStorage.getItem("last_ad_click");
  if (!last) return true;

  const now = Date.now();
  const oneDay = 24 * 60 * 60 * 1000;
  return now - parseInt(last, 10) > oneDay;
}

function registerAdClick() {
  localStorage.setItem("last_ad_click", Date.now());
}